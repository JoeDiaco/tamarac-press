console.log(`I was loaded at ${Date(Date.now()).toString()}`);
